import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Bombaysneakers112WixsiteComByH.module.css';
import { HeaderButtonSvgIcon } from './HeaderButtonSvgIcon';
import { SvgIcon } from './SvgIcon';
import { SvgWixIcon } from './SvgWixIcon';

interface Props {
  className?: string;
}
/* @figmaId 1:2 */
export const Bombaysneakers112WixsiteComByH: FC<Props> = memo(function Bombaysneakers112WixsiteComByH(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <button className={classes.mainButton}>
        <div className={classes.sVG}>
          <SvgIcon className={classes.icon} />
        </div>
        <div className={classes.heading2}>
          <div className={classes.letSChat}>Let&#39;s Chat!</div>
        </div>
      </button>
      <div className={classes.divLWbAav}></div>
      <div className={classes.header}></div>
      <div className={classes.header2}></div>
      <div className={classes.headerOurcomm}>ourcomm</div>
      <div className={classes.headerButtonLogIn}>Log In</div>
      <div className={classes.headerButtonSVG}>
        <HeaderButtonSvgIcon className={classes.icon2} />
      </div>
      <div className={classes.header3}></div>
      <div className={classes.headerWixDropdownMenuNavSiteLi}>About</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi2}>File Share</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi3}>Members</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi4}>Forum</div>
      <div className={classes.main}>
        <div className={classes.sectionSection}>
          <div className={classes.divLWbAav2}></div>
        </div>
        <div className={classes.sectionSection2}>
          <div className={classes.heading1}>
            <div className={classes.aboutOurcomm}>About ourcomm</div>
          </div>
          <div className={classes.pFont_8}>
            <div className={classes.learningFromEachOther}>Learning from Each Other</div>
          </div>
          <div className={classes.divCompLojwizfd}>
            <div className={classes.ourcommBeganWithASmallEnthusia}>
              ourcomm began with a small, enthusiastic group that wanted a place for academics to meet and
            </div>
            <div className={classes.conversationsAboutEducationToT}>
              conversations about education to thrive. Today, our platform is full of diverse topics and engaging
            </div>
            <div className={classes.conversationsCoveringAllAspect}>
              conversations covering all aspects of education. Get involved today to learn, share, connect and
            </div>
            <div className={classes.collaborateWithOurCommunity}>collaborate with our community.</div>
          </div>
        </div>
        <div className={classes.sectionSection3}>
          <div className={classes.divLWbAav3}></div>
        </div>
        <div className={classes.sectionSection4}>
          <div className={classes.heading22}>
            <div className={classes.guidelines}>Guidelines</div>
          </div>
          <div className={classes.pFont_82}>
            <div className={classes.forTheBenefitOfEveryone}>For the Benefit of Everyone</div>
          </div>
          <div className={classes.section}>
            <div className={classes.wowImageEmpty20School20Desks20}></div>
          </div>
          <div className={classes.section2}>
            <div className={classes.divCompLojwizff4}>
              <div className={classes.heading3NoPersonalAttacks}>No Personal Attacks</div>
              <div className={classes.alwaysApplies}>Always Applies</div>
            </div>
          </div>
          <div className={classes.section3}>
            <div className={classes.wowImageFemale20SpeakerJpg}></div>
          </div>
          <div className={classes.section4}>
            <div className={classes.heading3}>
              <div className={classes.noOffensiveImagery}>No Offensive Imagery</div>
            </div>
            <div className={classes.pFont_83}>
              <div className={classes.zeroTolerance}>Zero Tolerance</div>
            </div>
          </div>
        </div>
        <div className={classes.sectionSection5}>
          <div className={classes.divLWbAav4}></div>
        </div>
        <div className={classes.sectionSection6}>
          <div className={classes.section5}>
            <div className={classes.divLWbAav5}></div>
            <div className={classes.wowImage781083eaef2b4f8c9c8bcf}></div>
          </div>
          <div className={classes.section6}>
            <div className={classes.divCompLojwizfh7}>
              <div className={classes.PoorIsThePupilWhoDoesNotSurpas}>
                “Poor is the pupil who does not surpass his master.”
              </div>
            </div>
            <div className={classes.heading23}>
              <div className={classes.leonardoDaVinci}>Leonardo da Vinci</div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.footer}></div>
      <div className={classes.footer2}></div>
      <div className={classes.footerOurcomm}>ourcomm</div>
      <div className={classes.footerLinkInfoMysiteCom}>info@mysite.com</div>
      <div className={classes.footer2023ByOurcommProudlyCrea}>©2023 by ourcomm. Proudly created with Wix.com</div>
      <div className={classes.link}>
        <div className={classes.spanAreOb6}>
          <div className={classes.thisSiteWasDesignedWithThe}>This site was designed with the </div>
          <div className={classes.sVGWix}>
            <SvgWixIcon className={classes.icon3} />
          </div>
          <div className={classes.Com}>.com</div>
          <div className={classes.websiteBuilderCreateYourWebsit}> website builder. Create your website today.</div>
        </div>
        <div className={classes.spanO0tKs2}>
          <div className={classes.startNow}>Start Now</div>
        </div>
      </div>
    </div>
  );
});
