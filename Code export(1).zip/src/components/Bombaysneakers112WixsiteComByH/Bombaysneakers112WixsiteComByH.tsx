import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Bombaysneakers112WixsiteComByH.module.css';
import { HeaderButtonSvgIcon } from './HeaderButtonSvgIcon.js';
import { SvgIcon } from './SvgIcon.js';
import { SvgWixIcon } from './SvgWixIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 1:2 */
export const Bombaysneakers112WixsiteComByH: FC<Props> = memo(function Bombaysneakers112WixsiteComByH(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <button className={classes.mainButton}>
        <div className={classes.sVG}>
          <SvgIcon className={classes.icon} />
        </div>
        <div className={classes.heading2}>
          <div className={classes.letSChat}>Let&#39;s Chat!</div>
        </div>
      </button>
      <div className={classes.divBgLayers_pageBackground_cq3}>
        <div className={classes.divLWbAav}></div>
      </div>
      <div className={classes.header}></div>
      <div className={classes.header2}></div>
      <div className={classes.headerOurcomm}>ourcomm</div>
      <div className={classes.headerButtonLogIn}>Log In</div>
      <div className={classes.headerButtonSVG}>
        <HeaderButtonSvgIcon className={classes.icon2} />
      </div>
      <div className={classes.header3}></div>
      <div className={classes.headerWixDropdownMenuNavSiteLi}>About</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi2}>File Share</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi3}>Members</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi4}>Forum</div>
      <div className={classes.mainSectionIframeMembersBody}>
        <div className={classes.divMaBox}>
          <div className={classes.divPWEL6}>
            <div className={classes.logInToConnectWithMembers}>Log In to Connect With Members</div>
          </div>
          <div className={classes.divMaFontBodyM}>
            <div className={classes.viewAndFollowOtherMembersLeave}>
              <div className={classes.textBlock}>View and follow other members, leave</div>
              <div className={classes.textBlock2}>comments &amp; more.</div>
            </div>
          </div>
          <button className={classes.button}>
            <div className={classes.logIn}>Log In</div>
          </button>
        </div>
      </div>
      <div className={classes.footer}></div>
      <div className={classes.footer2}></div>
      <div className={classes.footerOurcomm}>ourcomm</div>
      <div className={classes.footerLinkInfoMysiteCom}>info@mysite.com</div>
      <div className={classes.footer2023ByOurcommProudlyCrea}>©2023 by ourcomm. Proudly created with Wix.com</div>
      <div className={classes.link}>
        <div className={classes.spanAreOb6}>
          <div className={classes.thisSiteWasDesignedWithThe}>This site was designed with the </div>
          <div className={classes.sVGWix}>
            <SvgWixIcon className={classes.icon3} />
          </div>
          <div className={classes.Com}>.com</div>
          <div className={classes.websiteBuilderCreateYourWebsit}> website builder. Create your website today.</div>
        </div>
        <div className={classes.spanO0tKs2}>
          <div className={classes.startNow}>Start Now</div>
        </div>
      </div>
    </div>
  );
});
