import { memo, SVGProps } from 'react';

const SvgIcon4 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M6 5H18C19.104 5 20 5.896 20 7V15C20 16.104 19.104 17 18 17H13.64L8.756 19.93C8.677 19.977 8.588 20 8.5 20C8.414 20 8.33 19.979 8.253 19.935C8.097 19.846 8 19.68 8 19.5V17H6C4.896 17 4 16.104 4 15V7C4 5.896 4.896 5 6 5ZM19 15V7C19 6.447 18.553 6 18 6H6C5.447 6 5 6.447 5 7V15C5 15.553 5.447 16 6 16H9V18.621L13.36 16H18C18.553 16 19 15.553 19 15Z'
      fill='#0D2123'
    />
  </svg>
);

const Memo = memo(SvgIcon4);
export { Memo as SvgIcon4 };
