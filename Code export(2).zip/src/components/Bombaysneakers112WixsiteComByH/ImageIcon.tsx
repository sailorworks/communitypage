import { memo, SVGProps } from 'react';

const ImageIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 30 30' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_1_222)'>
      <path
        d='M15 30C23.2843 30 30 23.2843 30 15C30 6.71573 23.2843 0 15 0C6.71573 0 0 6.71573 0 15C0 23.2843 6.71573 30 15 30Z'
        fill='#CCCCCC'
      />
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M24.924 26.2478C22.6037 24.4238 19.3086 23.1015 18.0876 22.9074C17.4775 22.8104 17.4636 21.1344 17.4636 21.1344C17.4636 21.1344 19.256 19.3612 19.6466 16.9769C20.6975 16.9769 21.3466 14.4419 20.2956 13.5501C20.3396 12.6111 21.6465 6.18 15.03 6.18C8.41347 6.18 9.72045 12.6111 9.76419 13.55C8.7132 14.4418 9.36219 16.9768 10.4132 16.9768C10.8038 19.3611 12.5962 21.1343 12.5962 21.1343C12.5962 21.1343 12.5823 22.8104 11.9723 22.9073C10.7458 23.1023 7.42614 24.4356 5.10423 26.2726C1.9752 23.5236 0 19.4925 0 15C0 6.71574 6.71574 0 15 0C23.2843 0 30 6.71574 30 15C30 19.479 28.0368 23.4993 24.924 26.2478Z'
        fill='#A0A09F'
      />
    </g>
    <defs>
      <clipPath id='clip0_1_222'>
        <rect width={30} height={30} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ImageIcon);
export { Memo as ImageIcon };
