import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Bombaysneakers112WixsiteComByH.module.css';
import { ButtonSvgIcon2 } from './ButtonSvgIcon2.js';
import { ButtonSvgIcon3 } from './ButtonSvgIcon3.js';
import { ButtonSvgIcon } from './ButtonSvgIcon.js';
import { HeaderButtonSvgIcon } from './HeaderButtonSvgIcon.js';
import { ImageIcon2 } from './ImageIcon2.js';
import { ImageIcon3 } from './ImageIcon3.js';
import { ImageIcon } from './ImageIcon.js';
import { LinkSvgIcon2 } from './LinkSvgIcon2.js';
import { LinkSvgIcon3 } from './LinkSvgIcon3.js';
import { LinkSvgIcon } from './LinkSvgIcon.js';
import { SvgAdminIcon2 } from './SvgAdminIcon2.js';
import { SvgAdminIcon3 } from './SvgAdminIcon3.js';
import { SvgAdminIcon } from './SvgAdminIcon.js';
import { SvgIcon2 } from './SvgIcon2.js';
import { SvgIcon3 } from './SvgIcon3.js';
import { SvgIcon4 } from './SvgIcon4.js';
import { SvgIcon5 } from './SvgIcon5.js';
import { SvgIcon6 } from './SvgIcon6.js';
import { SvgIcon7 } from './SvgIcon7.js';
import { SvgIcon8 } from './SvgIcon8.js';
import { SvgIcon9 } from './SvgIcon9.js';
import { SvgIcon } from './SvgIcon.js';
import { SvgWixIcon } from './SvgWixIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 1:2 */
export const Bombaysneakers112WixsiteComByH: FC<Props> = memo(function Bombaysneakers112WixsiteComByH(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <button className={classes.mainButton}>
        <div className={classes.sVG}>
          <SvgIcon className={classes.icon} />
        </div>
        <div className={classes.heading2}>
          <div className={classes.letSChat}>Let&#39;s Chat!</div>
        </div>
      </button>
      <div className={classes.divLWbAav}></div>
      <div className={classes.header}></div>
      <div className={classes.header2}></div>
      <div className={classes.headerOurcomm}>ourcomm</div>
      <div className={classes.headerButtonLogIn}>Log In</div>
      <div className={classes.headerButtonSVG}>
        <HeaderButtonSvgIcon className={classes.icon2} />
      </div>
      <div className={classes.header3}></div>
      <div className={classes.headerWixDropdownMenuNavSiteLi}>About</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi2}>File Share</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi3}>Members</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi4}>Forum</div>
      <div className={classes.mainSectionSection}>
        <div className={classes.divMluNwg}>
          <div className={classes.divRMfiZ6}>
            <div className={classes.divSksPSEX}>
              <div className={classes.nav}>
                <div className={classes.listItemLinkCategories}>Categories</div>
                <div className={classes.listItemLinkAllPosts}>All Posts</div>
                <div className={classes.listItemLinkMyPosts}>My Posts</div>
              </div>
            </div>
            <div className={classes.divJpY8nb}>
              <div className={classes.sVG2}>
                <SvgIcon2 className={classes.icon3} />
              </div>
              <div className={classes.formSearchSearch}>
                <div className={classes.divPlaceholder}>
                  <div className={classes.search}>Search</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.divDAP520}>
          <div className={classes.divLnqKOu}></div>
          <div className={classes.divWUsbqX}>
            <div className={classes.heading1}>
              <div className={classes.forum}>Forum</div>
            </div>
            <div className={classes.divLDnrup}>
              <div className={classes.pRvqllM}>
                <div className={classes.welcomeHaveALookAroundAndJoinT}>
                  Welcome! Have a look around and join the discussions.
                </div>
              </div>
            </div>
          </div>
        </div>
        <button className={classes.button}>
          <div className={classes.createNewPost}>Create New Post</div>
        </button>
        <div className={classes.list}>
          <div className={classes.item}>
            <div className={classes.link}></div>
          </div>
          <div className={classes.item2}>
            <div className={classes.linkHeading2}>
              <div className={classes.generalDiscussion}>General Discussion</div>
            </div>
            <div className={classes.pForumContentClassicFont}>
              <div className={classes.shareStoriesIdeasPicturesAndMo}>Share stories, ideas, pictures and more!</div>
            </div>
          </div>
          <div className={classes.item3}>
            <div className={classes.sVG3}>
              <SvgIcon3 className={classes.icon4} />
            </div>
            <div className={classes.unnamed}>0</div>
          </div>
          <div className={classes.item4}>
            <div className={classes.sVG4}>
              <SvgIcon4 className={classes.icon5} />
            </div>
            <div className={classes._3}>3</div>
          </div>
          <div className={classes.item5}>
            <div className={classes.buttonFollow}>Follow</div>
          </div>
          <div className={classes.item6}>
            <div className={classes.link2}></div>
          </div>
          <div className={classes.item7}>
            <div className={classes.linkHeading22}>
              <div className={classes.questionsAnswers}>Questions &amp; Answers</div>
            </div>
            <div className={classes.pForumContentClassicFont2}>
              <div className={classes.getAnswersAndShareKnowledge}>Get answers and share knowledge.</div>
            </div>
          </div>
          <div className={classes.item8}>
            <div className={classes.sVG5}>
              <SvgIcon5 className={classes.icon6} />
            </div>
            <div className={classes.unnamed2}>0</div>
          </div>
          <div className={classes.item9}>
            <div className={classes.sVG6}>
              <SvgIcon6 className={classes.icon7} />
            </div>
            <div className={classes.unnamed3}>0</div>
          </div>
          <div className={classes.item10}>
            <div className={classes.buttonFollow2}>Follow</div>
          </div>
        </div>
        <div className={classes.newPosts}>New Posts</div>
        <div className={classes.listItem}>
          <div className={classes.article}>
            <div className={classes.divFF9nIw}>
              <div className={classes.link3}>
                <div className={classes.divWqk07U}>
                  <div className={classes.imageFill}>
                    <div className={classes.image}>
                      <ImageIcon className={classes.icon8} />
                    </div>
                  </div>
                </div>
                <div className={classes.divVRhEBy}>
                  <div className={classes.divCpJeRR}>
                    <div className={classes.spanZREX02}>
                      <div className={classes.bombaySneakers}>Bombay Sneakers</div>
                    </div>
                    <div className={classes.sVGAdmin}>
                      <SvgAdminIcon className={classes.icon9} />
                    </div>
                  </div>
                  <div className={classes.spanSzoT9o}>
                    <div className={classes._2d}>2d</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.divT0n8Cv}>
              <div className={classes.divX2rEMQ}>
                <div className={classes.divNWUMmd}>
                  <div className={classes.linkWelcomeToTheForum}>Welcome to the Forum</div>
                </div>
              </div>
              <div className={classes.spanJ3QWxL}>
                <div className={classes.generalDiscussion2}>General Discussion</div>
              </div>
              <div className={classes.divWjGoxx}>
                <div className={classes.divQTTwUL}>
                  <div className={classes.shareYourThoughtsFeelFreeToAdd}>
                    <div className={classes.textBlock}>Share your thoughts. Feel free to</div>
                    <div className={classes.textBlock2}>add GIFs, videos, hashtags and mor…</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.div}>
              <div className={classes.divKpA7wg}></div>
              <div className={classes.buttonSVG}>
                <ButtonSvgIcon className={classes.icon10} />
              </div>
              <div className={classes.buttonLike}>Like</div>
              <div className={classes.linkSVG}>
                <LinkSvgIcon className={classes.icon11} />
              </div>
              <div className={classes.link4}>0</div>
              <div className={classes.sVG7}>
                <SvgIcon7 className={classes.icon12} />
              </div>
              <div className={classes.unnamed4}>0</div>
            </div>
          </div>
        </div>
        <div className={classes.listItem2}>
          <div className={classes.article2}>
            <div className={classes.divFF9nIw2}>
              <div className={classes.link5}>
                <div className={classes.divWqk07U2}>
                  <div className={classes.imageFill2}>
                    <div className={classes.image2}>
                      <ImageIcon2 className={classes.icon13} />
                    </div>
                  </div>
                </div>
                <div className={classes.divVRhEBy2}>
                  <div className={classes.divCpJeRR2}>
                    <div className={classes.spanZREX022}>
                      <div className={classes.bombaySneakers2}>Bombay Sneakers</div>
                    </div>
                    <div className={classes.sVGAdmin2}>
                      <SvgAdminIcon2 className={classes.icon14} />
                    </div>
                  </div>
                  <div className={classes.spanSzoT9o2}>
                    <div className={classes._2d2}>2d</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.divT0n8Cv2}>
              <div className={classes.divX2rEMQ2}>
                <div className={classes.divNWUMmd2}>
                  <div className={classes.linkIntroduceYourself}>Introduce yourself</div>
                </div>
              </div>
              <div className={classes.spanJ3QWxL2}>
                <div className={classes.generalDiscussion3}>General Discussion</div>
              </div>
              <div className={classes.divWjGoxx2}>
                <div className={classes.divQTTwUL2}>
                  <div className={classes.weDLoveToGetToKnowYouBetterTak}>
                    <div className={classes.textBlock3}>We&#39;d love to get to know you better.</div>
                    <div className={classes.textBlock4}>Take a moment to say hi to the…</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.div2}>
              <div className={classes.divKpA7wg2}></div>
              <div className={classes.buttonSVG2}>
                <ButtonSvgIcon2 className={classes.icon15} />
              </div>
              <div className={classes.buttonLike2}>Like</div>
              <div className={classes.linkSVG2}>
                <LinkSvgIcon2 className={classes.icon16} />
              </div>
              <div className={classes.link6}>0</div>
              <div className={classes.sVG8}>
                <SvgIcon8 className={classes.icon17} />
              </div>
              <div className={classes.unnamed5}>0</div>
            </div>
          </div>
        </div>
        <div className={classes.listItem3}>
          <div className={classes.article3}>
            <div className={classes.divFF9nIw3}>
              <div className={classes.link7}>
                <div className={classes.divWqk07U3}>
                  <div className={classes.imageFill3}>
                    <div className={classes.image3}>
                      <ImageIcon3 className={classes.icon18} />
                    </div>
                  </div>
                </div>
                <div className={classes.divVRhEBy3}>
                  <div className={classes.divCpJeRR3}>
                    <div className={classes.spanZREX023}>
                      <div className={classes.bombaySneakers3}>Bombay Sneakers</div>
                    </div>
                    <div className={classes.sVGAdmin3}>
                      <SvgAdminIcon3 className={classes.icon19} />
                    </div>
                  </div>
                  <div className={classes.spanSzoT9o3}>
                    <div className={classes._2d3}>2d</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.divT0n8Cv3}>
              <div className={classes.divX2rEMQ3}>
                <div className={classes.divNWUMmd3}>
                  <div className={classes.linkForumRules}>Forum rules</div>
                </div>
              </div>
              <div className={classes.spanJ3QWxL3}>
                <div className={classes.generalDiscussion4}>General Discussion</div>
              </div>
              <div className={classes.divWjGoxx3}>
                <div className={classes.divQTTwUL3}>
                  <div className={classes.weWantEveryoneToGetTheMostOutO}>
                    <div className={classes.textBlock5}>We want everyone to get the most</div>
                    <div className={classes.textBlock6}>out of this community, so we ask…</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.div3}>
              <div className={classes.divKpA7wg3}></div>
              <div className={classes.buttonSVG3}>
                <ButtonSvgIcon3 className={classes.icon20} />
              </div>
              <div className={classes.buttonLike3}>Like</div>
              <div className={classes.linkSVG3}>
                <LinkSvgIcon3 className={classes.icon21} />
              </div>
              <div className={classes.link8}>0</div>
              <div className={classes.sVG9}>
                <SvgIcon9 className={classes.icon22} />
              </div>
              <div className={classes.unnamed6}>0</div>
            </div>
          </div>
        </div>
      </div>
      <div className={classes.footer}></div>
      <div className={classes.footer2}></div>
      <div className={classes.footerOurcomm}>ourcomm</div>
      <div className={classes.footerLinkInfoMysiteCom}>info@mysite.com</div>
      <div className={classes.footer2023ByOurcommProudlyCrea}>©2023 by ourcomm. Proudly created with Wix.com</div>
      <div className={classes.link9}>
        <div className={classes.spanAreOb6}>
          <div className={classes.thisSiteWasDesignedWithThe}>This site was designed with the </div>
          <div className={classes.sVGWix}>
            <SvgWixIcon className={classes.icon23} />
          </div>
          <div className={classes.Com}>.com</div>
          <div className={classes.websiteBuilderCreateYourWebsit}> website builder. Create your website today.</div>
        </div>
        <div className={classes.spanO0tKs2}>
          <div className={classes.startNow}>Start Now</div>
        </div>
      </div>
    </div>
  );
});
