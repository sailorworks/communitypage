import { memo, SVGProps } from 'react';

const ImgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 15 16' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_1_120)'>
      <path
        opacity={0.8}
        fillRule='evenodd'
        clipRule='evenodd'
        d='M7.03 0C8.31846 7.44425e-05 9.55716 0.497541 10.4878 1.38866C11.4184 2.27978 11.9691 3.49575 12.025 4.783L12.03 5V7H14.03V16H0.0299988V7H2.03V5C2.03 3.67392 2.55678 2.40215 3.49446 1.46447C4.43215 0.526784 5.70392 0 7.03 0ZM13.03 8H1.03V15H13.03V8ZM7.03 1C6.00376 0.999999 5.01677 1.39444 4.27319 2.10172C3.5296 2.80901 3.08631 3.77504 3.035 4.8L3.03 5V7H11.03V5C11.03 3.93913 10.6086 2.92172 9.85843 2.17157C9.10828 1.42143 8.09086 1 7.03 1Z'
        fill='#0D2123'
      />
    </g>
    <defs>
      <clipPath id='clip0_1_120'>
        <rect width={14} height={16} fill='white' transform='translate(0.0299988)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ImgIcon);
export { Memo as ImgIcon };
