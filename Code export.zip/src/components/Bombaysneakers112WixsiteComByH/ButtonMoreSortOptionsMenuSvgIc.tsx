import { memo, SVGProps } from 'react';

const ButtonMoreSortOptionsMenuSvgIc = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 16 15' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_1_108)'>
      <g opacity={0.6}>
        <path
          fillRule='evenodd'
          clipRule='evenodd'
          d='M1.21238 2.46997C0.546425 2.46997 0 2.01927 0 1.46997C0 0.920675 0.546425 0.469971 1.21238 0.469971H14.7876C15.4536 0.469971 16 0.920675 16 1.46997C16 2.01927 15.4707 2.46997 14.8047 2.46997H1.21238Z'
          fill='#0D2123'
        />
        <path
          fillRule='evenodd'
          clipRule='evenodd'
          d='M9.95095 8.46997H1.06403C0.479564 8.46997 0 8.01927 0 7.46997C0 6.92067 0.479564 6.46997 1.06403 6.46997H9.93597C10.5204 6.46997 11 6.92067 11 7.46997C11 8.01927 10.5354 8.46997 9.95095 8.46997Z'
          fill='#0D2123'
        />
        <path
          fillRule='evenodd'
          clipRule='evenodd'
          d='M6.93233 14.47H1.06767C0.481203 14.47 0 14.0193 0 13.47C0 12.9207 0.481203 12.47 1.06767 12.47H6.93233C7.51865 12.47 8 12.9207 8 13.47C8 14.0193 7.51865 14.47 6.93233 14.47Z'
          fill='#0D2123'
        />
      </g>
    </g>
    <defs>
      <clipPath id='clip0_1_108'>
        <rect width={16} height={14} fill='white' transform='translate(0 0.469999)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ButtonMoreSortOptionsMenuSvgIc);
export { Memo as ButtonMoreSortOptionsMenuSvgIc };
