import { memo, SVGProps } from 'react';

const SvgIcon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 8 15' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_1_106)'>
      <path
        d='M4.72 12.9L6.92 11C7.12 10.8 7.42 10.8 7.62 11C7.82 11.2 7.72 11.5 7.52 11.7L4.52 14.3C4.52 14.3 4.42 14.4 4.32 14.4C4.12 14.5 3.92 14.5 3.82 14.4L0.819998 11.8C0.619998 11.6 0.619998 11.3 0.719998 11.1C0.919998 10.9 1.22 10.9 1.42 11L3.72 12.9V1C3.72 0.7 3.92 0.5 4.22 0.5C4.52 0.5 4.72 0.7 4.72 1V12.9Z'
        fill='#0D2123'
      />
    </g>
    <defs>
      <clipPath id='clip0_1_106'>
        <rect width={7} height={14} fill='white' transform='translate(0.720001 0.5)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(SvgIcon3);
export { Memo as SvgIcon3 };
