import { memo, SVGProps } from 'react';

const ButtonSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 17 16' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_1_122)'>
      <path
        opacity={0.8}
        fillRule='evenodd'
        clipRule='evenodd'
        d='M12.875 14.816L11.966 9.863L15.369 6.898L10.752 6.589L8.597 1.916L6.263 6.695L1.909 6.915L5.689 10.075L4.445 14.762L8.611 12.519L12.875 14.816Z'
        stroke='#0D2123'
      />
    </g>
    <defs>
      <clipPath id='clip0_1_122'>
        <rect width={16} height={15} fill='white' transform='translate(0.609985 0.75)' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(ButtonSvgIcon);
export { Memo as ButtonSvgIcon };
