import { memo, SVGProps } from 'react';

const SectionSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 44' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M35.5 13H23L13 11L3 13V35.5C3 36.329 3.672 37 4.5 37H35.5C36.328 37 37 36.329 37 35.5V14.5C37 13.671 36.328 13 35.5 13Z'
      fill='#0D2123'
    />
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M23 13H13H3V9.5C3 8.671 3.672 8 4.5 8H17.271C17.967 8 18.632 8.29 19.104 8.8L23 13Z'
      fill='white'
    />
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M23 13H13H3V9.5C3 8.671 3.672 8 4.5 8H17.271C17.967 8 18.632 8.29 19.104 8.8L23 13Z'
      fill='#0D2123'
      fillOpacity={0.6}
    />
  </svg>
);

const Memo = memo(SectionSvgIcon);
export { Memo as SectionSvgIcon };
