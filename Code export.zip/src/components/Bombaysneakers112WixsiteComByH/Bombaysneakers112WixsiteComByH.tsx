import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Bombaysneakers112WixsiteComByH.module.css';
import { ButtonItemSvgIcon } from './ButtonItemSvgIcon.js';
import { ButtonMoreSortOptionsMenuSvgIc } from './ButtonMoreSortOptionsMenuSvgIc.js';
import { ButtonSvgIcon } from './ButtonSvgIcon.js';
import { HeaderButtonSvgIcon } from './HeaderButtonSvgIcon.js';
import { ImgIcon } from './ImgIcon.js';
import { SectionSvgIcon } from './SectionSvgIcon.js';
import { SvgIcon2 } from './SvgIcon2.js';
import { SvgIcon3 } from './SvgIcon3.js';
import { SvgIcon } from './SvgIcon.js';
import { SvgWixIcon } from './SvgWixIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 1:2 */
export const Bombaysneakers112WixsiteComByH: FC<Props> = memo(function Bombaysneakers112WixsiteComByH(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <button className={classes.mainButton}>
        <div className={classes.sVG}>
          <SvgIcon className={classes.icon} />
        </div>
        <div className={classes.heading2}>
          <div className={classes.letSChat}>Let&#39;s Chat!</div>
        </div>
      </button>
      <div className={classes.divBgLayers_pageBackground_gue}>
        <div className={classes.divLWbAav}></div>
      </div>
      <div className={classes.header}></div>
      <div className={classes.header2}></div>
      <div className={classes.headerOurcomm}>ourcomm</div>
      <div className={classes.headerButtonLogIn}>Log In</div>
      <div className={classes.headerButtonSVG}>
        <HeaderButtonSvgIcon className={classes.icon2} />
      </div>
      <div className={classes.header3}></div>
      <div className={classes.headerWixDropdownMenuNavSiteLi}>About</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi2}>File Share</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi3}>Members</div>
      <div className={classes.headerWixDropdownMenuNavSiteLi4}>Forum</div>
      <div className={classes.mainSectionIframeFileShare}>
        <div className={classes.body}>
          <div className={classes.sectionSectionNavigationBreadC}>
            <div className={classes.navListBreadCrumbsItemFilesFol}>Files &amp; Folders</div>
          </div>
          <div className={classes.sectionSectionSectionSearchBut}>
            <div className={classes.sVG2}>
              <SvgIcon2 className={classes.icon3} />
            </div>
          </div>
          <button className={classes.sectionSectionButtonNewFile}>
            <div className={classes.File}>+ File</div>
          </button>
          <div className={classes.sectionButtonSortByItemName}>
            <div className={classes.divClipOverflowedTexts}>
              <div className={classes.itemName}>Item name</div>
            </div>
          </div>
          <div className={classes.sectionButtonSortByLastUpdated}>
            <div className={classes.divClipOverflowedTexts2}>
              <div className={classes.lastUpdated}>Last updated</div>
            </div>
            <div className={classes.sVG3}>
              <SvgIcon3 className={classes.icon4} />
            </div>
          </div>
          <div className={classes.sectionButtonSortByViews}>
            <div className={classes.divClipOverflowedTexts3}>
              <div className={classes.views}>Views</div>
            </div>
          </div>
          <div className={classes.sectionButtonSortByFavorites}>
            <div className={classes.divClipOverflowedTexts4}>
              <div className={classes.favorites}>Favorites</div>
            </div>
          </div>
          <div className={classes.section}>
            <div className={classes.contributors}>Contributors</div>
          </div>
          <div className={classes.section2}>
            <div className={classes.buttonMoreSortOptionsMenuSVG}>
              <ButtonMoreSortOptionsMenuSvgIc className={classes.icon5} />
            </div>
          </div>
          <div className={classes.sectionSectionListItem}>
            <div className={classes.separator}></div>
            <div className={classes.separator2}></div>
            <div className={classes.sectionSVG}>
              <SectionSvgIcon className={classes.icon6} />
            </div>
            <div className={classes.sectionLink}>
              <div className={classes.spanLabel}>
                <div className={classes.fAQ}>FAQ</div>
              </div>
              <div className={classes.divFlexChild}>
                <div className={classes.spanFileSizeLabel}>
                  <div className={classes._1Item}>1 item</div>
                </div>
              </div>
            </div>
            <div className={classes.img}>
              <ImgIcon className={classes.icon7} />
            </div>
            <div className={classes.nov42023Nov42023}>Nov 4, 2023</div>
            <div className={classes.textboxViewsLabelViews}>0</div>
            <div className={classes.buttonSVG}>
              <ButtonSvgIcon className={classes.icon8} />
            </div>
            <div className={classes.buttonLabelFavorites}>0</div>
            <div className={classes.divAvatarIcon}>
              <div className={classes.labelB}>B</div>
            </div>
            <div className={classes.label}>
              <div className={classes.bombaySneak}>Bombay Sneak…</div>
            </div>
            <div className={classes.buttonItemSVG}>
              <ButtonItemSvgIcon className={classes.icon9} />
            </div>
          </div>
        </div>
      </div>
      <div className={classes.footer}></div>
      <div className={classes.footer2}></div>
      <div className={classes.footerOurcomm}>ourcomm</div>
      <div className={classes.footerLinkInfoMysiteCom}>info@mysite.com</div>
      <div className={classes.footer2023ByOurcommProudlyCrea}>©2023 by ourcomm. Proudly created with Wix.com</div>
      <div className={classes.link}>
        <div className={classes.spanAreOb6}>
          <div className={classes.thisSiteWasDesignedWithThe}>This site was designed with the </div>
          <div className={classes.sVGWix}>
            <SvgWixIcon className={classes.icon10} />
          </div>
          <div className={classes.Com}>.com</div>
          <div className={classes.websiteBuilderCreateYourWebsit}> website builder. Create your website today.</div>
        </div>
        <div className={classes.spanO0tKs2}>
          <div className={classes.startNow}>Start Now</div>
        </div>
      </div>
    </div>
  );
});
